//package P09InterfacesAndAbstraction.P02CarShopExtend;

public interface Rentable {
    Integer getMinRentDay();

    Double getPricePerDay();
}

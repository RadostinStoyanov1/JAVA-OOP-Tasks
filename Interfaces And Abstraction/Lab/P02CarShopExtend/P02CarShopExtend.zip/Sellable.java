//package P09InterfacesAndAbstraction.P02CarShopExtend;

public interface Sellable {

    Double getPrice();
}

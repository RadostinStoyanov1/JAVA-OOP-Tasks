//package P09InterfacesAndAbstraction.P05BorderControl;

public interface Identifiable {
    String getId();
}

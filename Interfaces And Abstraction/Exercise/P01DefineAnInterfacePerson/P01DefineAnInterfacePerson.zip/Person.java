//package P10InheritanceAndAbstraction_Exercise.P01DefineAnInterfacePerson;

public interface Person {

    String getName();

    int getAge();
}

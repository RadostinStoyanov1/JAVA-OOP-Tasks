package food_shortage;

public interface Person {

    String getName();

    int getAge();
}

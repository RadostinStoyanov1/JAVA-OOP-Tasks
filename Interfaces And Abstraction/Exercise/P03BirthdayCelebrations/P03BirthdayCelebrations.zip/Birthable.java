//package P10InheritanceAndAbstraction_Exercise.P03BirthdayCelebrations;

public interface Birthable {

    String getBirthDate();
}

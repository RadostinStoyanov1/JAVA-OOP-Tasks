//package P10InheritanceAndAbstraction_Exercise.P02MultipleImplementation;

public interface Birthable {

    String getBirthDate();
}

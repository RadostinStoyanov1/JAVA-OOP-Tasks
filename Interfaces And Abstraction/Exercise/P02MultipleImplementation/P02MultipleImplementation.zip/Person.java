//package P10InheritanceAndAbstraction_Exercise.P02MultipleImplementation;

public interface Person {

    String getName();

    int getAge();
}

//package P10InheritanceAndAbstraction_Exercise.P02MultipleImplementation;

public interface Identifiable {

    String getId();
}

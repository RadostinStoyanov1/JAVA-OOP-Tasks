//package P10InheritanceAndAbstraction_Exercise.P05Telephony;

public interface Browsable {
    String browse();
}

package P04WorkingWithAbstraction_Exercise.P04TrafficLights;

public enum Signals {
    RED,
    GREEN,
    YELLOW;
}

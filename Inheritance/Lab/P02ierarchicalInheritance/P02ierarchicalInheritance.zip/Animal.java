//package P07Inheritance.P02ierarchicalInheritance;

public class Animal {
    public void eat() {
        System.out.println("eating...");
    }
}

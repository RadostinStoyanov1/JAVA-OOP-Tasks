//package P07Inheritance.P02ierarchicalInheritance;

public class Cat extends Animal {
    public void meow() {
        System.out.println("meowing...");
    }
}

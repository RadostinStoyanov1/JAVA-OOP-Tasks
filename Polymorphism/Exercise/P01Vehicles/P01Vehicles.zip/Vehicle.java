//package P12Polymorphism_Exercise.P01Vehicles;

public interface Vehicle {

    String drive(double distance);
    void refuel(double liters);

}

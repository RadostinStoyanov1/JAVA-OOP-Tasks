package calculator;

public class MemoryStorage {
}

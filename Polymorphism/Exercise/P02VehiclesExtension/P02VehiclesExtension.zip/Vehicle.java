//package P12Polymorphism_Exercise.P02VehiclesExtension;

public interface Vehicle {

    String drive(double distance);
    void refuel(double liters);

}

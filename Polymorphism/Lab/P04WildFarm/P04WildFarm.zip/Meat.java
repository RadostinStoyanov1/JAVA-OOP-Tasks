//package P11Polymorphism.P04WildFarm;

public class Meat extends Food{
    public Meat(Integer quantity) {
        super(quantity);
    }
}

//package P11Polymorphism.P04WildFarm;

public class Vegetable extends Food{
    public Vegetable(Integer quantity) {
        super(quantity);
    }
}

package P04WorkingWithAbstraction_Exercise.greedyTimes;

public enum ItemType {
    GOLD,
    GEM,
    CASH;
}

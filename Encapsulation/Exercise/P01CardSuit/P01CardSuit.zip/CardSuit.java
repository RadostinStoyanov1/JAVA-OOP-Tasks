package P04WorkingWithAbstraction_Exercise.P01CardSuit;

public enum CardSuit {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES;
}
